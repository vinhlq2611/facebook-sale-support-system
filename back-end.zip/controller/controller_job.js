const { UserService, FacebookService, OrderService } = require("../services");
const { logError, logWarn, isVietnamesePhoneNumber } = require("../utils/index");
const jwt = require("jsonwebtoken");
const { JobModel } = require("../models");
const JobController = {
    
}
module.exports = JobController
